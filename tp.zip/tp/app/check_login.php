<?php
echo json_encode(['exists' => file_exists('data/login.json')]);

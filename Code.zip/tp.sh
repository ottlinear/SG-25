#!/bin/bash
cd tp
php -S localhost:8002